using System.Text.Json.Serialization;

namespace DataOperations
{
   
    public class Deferral {
        public string uri { get; set; }
    }
}
