
public enum FilterOperator
{
    eq,
    ne,
    lt,
    gt,
    le,
    endswith,
    startswith,
    contains,
    extended
}
