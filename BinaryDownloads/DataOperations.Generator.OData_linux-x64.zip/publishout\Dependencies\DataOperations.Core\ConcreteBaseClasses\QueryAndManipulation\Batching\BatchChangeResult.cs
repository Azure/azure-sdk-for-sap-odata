
namespace DataOperations
{
    public class BatchChangeResult
    {
        // object entity, HttpMethod method, string uri
        public object Entity { get; set; }
        public int status {get;set;}
    }
}