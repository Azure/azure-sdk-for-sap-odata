namespace DataOperations.OData.Client
{
    public class ODataHttpClientContextOptions
    {
        public string NamedHttpClientName {get;set;}
        public string NamedHttpClientBaseUri {get;set;}
    }
}
