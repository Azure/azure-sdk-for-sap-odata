public class IfMatchEtag {
    public string ETag{ get; set; }
}
