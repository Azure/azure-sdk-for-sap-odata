namespace DataOperations.Core.Auth.Http
{
    public class BasicHttpAuthHandlerOptions
    {
        public string UserName {get; set;}
        public string Password {get; set;}
    }
}