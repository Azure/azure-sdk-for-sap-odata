namespace DataOperations.Bindings
{
    public interface IOutputAttribute {}
}