namespace DataOperations.OData.Client
{
    public class ODataOperationsDispatcherOptions
    {
        public string ServiceRootPrefix {get;set;}
    }
}
