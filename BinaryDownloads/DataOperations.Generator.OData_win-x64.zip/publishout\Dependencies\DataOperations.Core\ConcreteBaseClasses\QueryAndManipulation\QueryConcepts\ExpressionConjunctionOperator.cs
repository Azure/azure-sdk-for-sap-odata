
public enum FilterConjunctionOperator 
{
    root,
    and,
    or
}