namespace DataOperations.Bindings
{
    public interface IInputAttribute{}
}